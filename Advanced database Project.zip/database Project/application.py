from flask import Flask, render_template, request, url_for, redirect, session, flash
from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.binary import Binary
import base64
import io

app = Flask(__name__)
app.secret_key = 'your_secret_key'
client = MongoClient('localhost', 27017)

db = client.Customer_database
users = db.users
customerss = db.customers
equipmentss = db.equipments
employees = db.employees

@app.route("/", methods=['GET', 'POST'])
def home():
    if 'visited' not in session:
        session['visited'] = True
        return redirect(url_for('login'))
    return redirect(url_for('index'))

@app.route("/index", methods=['GET', 'POST'])
def index():
    if 'username' not in session:
        return redirect(url_for('login'))
    if request.method == "POST":   # if the request method is post, then insert the todo document in todos collection
        content = request.form['content']
        degree = request.form['degree']
        todos.insert_one({'content': content, 'degree': degree})
        return redirect(url_for('index')) # redirect the user to home page
    all_todos = todos.find()    # display all todo documents
    return render_template('index.html', todos=all_todos) # render home page template with all todos

@app.route("/login", methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = users.find_one({"username": username})
        if user and user['password'] == password:
            session['username'] = username
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password')
    return render_template('login.html')

@app.route("/signup", methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check if the username already exists
        if users.find_one({"username": username}):
            flash('Username already exists. Please choose a different one.')
            return render_template('signup.html')
        
        # Insert the new user
        users.insert_one({"username": username, "password": password})
        
        # Log in the new user
        session['username'] = username
        
        # Redirect to the index page
        return redirect(url_for('index'))
    
    return render_template('signup.html')

@app.route("/logout")
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

@app.route("/customers", methods=['GET', 'POST'])
def customers():
    if 'username' not in session:
        return redirect(url_for('login'))
    message = ""
    if request.method == "POST":  # Insert new customer data
        # Create a dynamic dictionary with only non-empty fields
        customer_data = {
            key: value.strip()
            for key, value in {
                "customer_id": request.form.get('customer-id', ""),
                "customer_name": request.form.get('customer-name', ""),
                "customer_age": request.form.get('customer-age', ""),
                "customer_blood": request.form.get('customer-blood', ""),
                "customer_duration": request.form.get('customer-duration', ""),
            }.items()
            if value.strip()  # Include only fields with non-empty values
        }

        # Handle image upload if provided
        customer_image_file = request.files.get('customer-image')
        if customer_image_file and customer_image_file.filename:  # Check if an image is uploaded
            customer_data["customer_image"] = Binary(customer_image_file.read())

        # Insert data into the database
        results = customerss.insert_one(customer_data)
        if results.inserted_id:
            message = "Customer data was successfully inserted into the database!"
        else:
            message = "Failed to insert customer data into the database!"

        return redirect(url_for('customers'))  # Redirect after POST

    all_customers = customerss.find()  # Fetch all customer documents
    return render_template('customer.html', customers=all_customers, message=message)
#####################################################3
@app.route("/equipments", methods=['GET', 'POST'])
def equipments():
    message = ""
    if request.method == "POST":  # Insert new equipment data
        # Create a dynamic dictionary with only non-empty fields
        equipment_data = {
            key: value.strip()
            for key, value in {
                "equipment_id": request.form.get('equipment-id', ""),
                "equipment_name": request.form.get('equipment-name', ""),
            }.items()
            if value.strip()  # Include only fields with non-empty values
        }

        # Handle image upload if provided
        equipment_image_file = request.files.get('equipment-image')
        if equipment_image_file and equipment_image_file.filename:  # Check if an image is uploaded
            equipment_data["equipment_image"] = Binary(equipment_image_file.read())

        # Handle barcode upload if provided
        equipment_barcode_file = request.files.get('equipment-barcode')
        if equipment_barcode_file and equipment_barcode_file.filename:  # Check if a barcode is uploaded
            equipment_data["equipment_barcode"] = Binary(equipment_barcode_file.read())

        # Insert data into the database
        results = equipmentss.insert_one(equipment_data)
        if results.inserted_id:
            message = "Equipment data was successfully inserted into the database!"
        else:
            message = "Failed to insert equipment data into the database."

        return redirect(url_for('equipments', message=message))  # Redirect after POST

    equipments_list = equipmentss.find()  # Fetch all equipment documents
    return render_template('equipment.html', equipments=equipments_list, message=message)
##########################################################################3







@app.route("/employees", methods=['GET', 'POST'])
def employees():
    message = request.args.get('message', "")
    if request.method == "POST":  # Insert new employee data
        # Create a dynamic dictionary with only non-empty fields
        employee_data = {
            key: value.strip()
            for key, value in {
                "employee_id": request.form.get('employee-id', ""),
                "employee_name": request.form.get('employee-name', ""),
                "employee_salary": request.form.get('employee-salary', ""),
                "employee_role": request.form.get('employee-role', ""),
                "employee_address": request.form.get('employee-address', ""),
                "employee_training": request.form.get('employee-training', ""),
                "employee_phone": request.form.get('employee-phone', ""),
                "employee_education": request.form.get('employee-education', ""),
            }.items()
            if value.strip()  # Include only fields with non-empty values
        }

        # Handle image upload if provided
        employee_image_file = request.files.get('employee-image')
        if employee_image_file and employee_image_file.filename:  # Check if an image is uploaded
            employee_data["employee_image"] = Binary(employee_image_file.read())

        # Insert data into the database
        results = employees.insert_one(employee_data)
        if results.inserted_id:
            message = "Employee data was successfully inserted into the database!"
        else:
            message = "Failed to insert employee data into the database!"

        return redirect(url_for('employees', message=message))  # Redirect after POST

    all_employees = employees.find()  # Fetch all employee documents
    return render_template('employee.html', employees=all_employees, message=message)



 
######################################
#Delete Route
@app.post("/<id>/delete/")
def delete(id): #delete function by targeting a todo document by its own id
    todos.delete_one({"_id": ObjectId(id)}) #deleting the selected todo document by its converted id
    return redirect(url_for('index')) # again, redirecting you to the home page 

# Delete route for customers by customer_id
@app.post("/customers/delete/")
def delete_customer():
    customer_id = request.form['customer-id']  # Get the customer_id from the form input
    result = customerss.delete_one({"customer_id": customer_id})  # Delete the customer by customer_id
    if result.deleted_count > 0:
        message = f"Customer with ID {customer_id} was successfully deleted!"
    else:
        message = f"No customer found with ID {customer_id}."

    return redirect(url_for('customers'))  # Redirect to the customers route

@app.post("/employees/delete/")
def delete_employee():
    employee_id = request.form['employee-id']  # Get the employee_id from the form input
    result = employees.delete_one({"employee_id": employee_id})  # Delete the employee by employee_id
    if result.deleted_count > 0:
        message = f"Employee with ID {employee_id} was successfully deleted!"
    else:
        message = f"No employee found with ID {employee_id}."
    
    return redirect(url_for('employees', message=message))  # Redirect to the employees route


@app.post("/equipments/delete/")
def delete_equipments():
    equipment_id = request.form['equipment-id']  # Get the equipment_id from the form input
    result = equipmentss.delete_one({"equipment_id": equipment_id})  # Delete the equipment by equipment_id
    if result.deleted_count > 0:
        message = f"Equipment with ID {equipment_id} was successfully deleted!"
    else:
        message = f"No equipment found with ID {equipment_id}."

    return redirect(url_for('equipments'))  # Redirect to the equipments route



#############################################################################

@app.route("/customers/update", methods=['POST'])
def redirect_to_update():
    customer_id = request.form['customer-id']
    return redirect(url_for('update_customer_page', customer_id=customer_id))
@app.route("/customers/update/<customer_id>", methods=['GET', 'POST'])
def update_customer_page(customer_id):
    message = ""

    # Fetch customer data using customer_id
    customer = customerss.find_one({"customer_id": customer_id})
    if not customer:
        message = f"Customer with ID {customer_id} not found."
        return render_template('customer.html', message=message, customers=customerss.find())

    # Convert customer image to base64 for display
    import base64
    customer_image = base64.b64encode(customer["customer_image"]).decode('utf-8') if customer.get("customer_image") else ""

    if request.method == "POST":
        # Get updated data
        customer_name = request.form['customer-name']
        customer_age = request.form['customer-age']
        customer_blood = request.form.get('customer-blood', "")
        customer_duration = request.form['customer-duration']

        # Handle new image upload if provided
        customer_image_file = request.files['customer-image']
        if customer_image_file:
            customer_image_binary = Binary(customer_image_file.read())
        else:
            customer_image_binary = customer["customer_image"]

        # Prepare the updated data
        updated_data = {
            "customer_name": customer_name,
            "customer_age": customer_age,
            "customer_blood": customer_blood,
            "customer_duration": customer_duration,
            "customer_image": customer_image_binary,
        }

        # Update the database
        result = customerss.update_one({"customer_id": customer_id}, {"$set": updated_data})
        if result.modified_count > 0:
            message = f"Customer with ID {customer_id} was successfully updated!"
        else:
            message = f"No changes were made to customer with ID {customer_id}."

    return render_template('update_customer.html', customer=customer, customer_image=customer_image, message=message)


@app.route("/employees/edit", methods=["POST"])
def edit_employee():
    employee_id = request.form['employee-id']  # Get the employee ID entered by the user
    # Fetch the employee details from the database using the ID
    employee = employees.find_one({"employee_id": employee_id})

    if employee:
        # Convert employee image to base64 for display
        import base64
        employee_image = base64.b64encode(employee["employee_image"]).decode('utf-8') if employee.get("employee_image") else ""
        
        # If the employee exists, redirect to the update page with the employee data
        return render_template('edit_employee.html', employee=employee, employee_image=employee_image)
    else:
        # If no employee is found with that ID, show an error message
        return render_template('employee_list.html', message="Employee ID not found.")


@app.route("/employees/update/<employee_id>", methods=["POST"])
def update_employee(employee_id):
    # Get the updated data from the form
    updated_data = {
        "employee_name": request.form['employee-name'],
        "employee_salary": request.form['employee-salary'],
        "employee_role": request.form['employee-role'],
        "employee_address": request.form['employee-address'],
        "employee_phone": request.form['employee-phone'],
        "employee_education": request.form['employee-education'],
    }

    # Handle new image upload if provided
    employee_image_file = request.files['employee-image']
    if employee_image_file:
        updated_data["employee_image"] = Binary(employee_image_file.read())

    # Update the employee data in the database
    result = employees.update_one({"employee_id": employee_id}, {"$set": updated_data})

    if result.modified_count > 0:
        # If the update was successful, redirect to the employee list page with a success message
        return redirect(url_for('employees', message="Employee updated successfully"))
    else:
        # If no changes were made, redirect with a message
        return redirect(url_for('employees', message="No changes made to the employee data"))

@app.route("/equipments/update", methods=['POST'])  # Fix: Added quotes around 'POST'
def redirect_to_update_equipment():
    equipment_id = request.form['equipment-id']
    return redirect(url_for('update_equipment_page', equipment_id=equipment_id))
@app.route("/equipments/update/<equipment_id>", methods=['GET', 'POST'])
def update_equipment_page(equipment_id):
    message = ""

    # Fetch equipment data using equipment_id
    equipment = equipmentss.find_one({"equipment_id": equipment_id})
    if not equipment:
        message = f"Equipment with ID {equipment_id} not found."
        return render_template('equipment.html', message=message, equipments=equipmentss.find())

    # Convert equipment image and barcode to base64 for display
    import base64
    equipment_image = base64.b64encode(equipment["equipment_image"]).decode('utf-8') if equipment.get("equipment_image") else ""
    equipment_barcode = base64.b64encode(equipment["equipment_barcode"]).decode('utf-8') if equipment.get("equipment_barcode") else ""

    if request.method == "POST":
        # Get updated data
        equipment_name = request.form['equipment-name']

        # Handle new image upload if provided
        equipment_image_file = request.files['equipment-image']
        if equipment_image_file:
            equipment_image_binary = Binary(equipment_image_file.read())
        else:
            equipment_image_binary = equipment["equipment_image"]

        # Handle new barcode upload if provided
        equipment_barcode_file = request.files['equipment-barcode']
        if equipment_barcode_file:
            equipment_barcode_binary = Binary(equipment_barcode_file.read())
        else:
            equipment_barcode_binary = equipment["equipment_barcode"]

        # Prepare the updated data
        updated_data = {
            "equipment_name": equipment_name,
            "equipment_image": equipment_image_binary,
            "equipment_barcode": equipment_barcode_binary,
        }

        # Update the database
        result = equipmentss.update_one({"equipment_id": equipment_id}, {"$set": updated_data})
        if result.modified_count > 0:
            message = f"Equipment with ID {equipment_id} was successfully updated!"
        else:
            message = f"No changes were made to equipment with ID {equipment_id}."

    return render_template('update_equipment.html', equipment=equipment, equipment_image=equipment_image, equipment_barcode=equipment_barcode, message=message)

  

#############################################################################
# Search customers
@app.route("/customers/search", methods=["GET", "POST"])
def search_customers():
    results = []
    if request.method == "POST":
        action = request.form.get("action")
        sort_by = request.form.get("sort", "")
        
        search_criteria = {}
        
        if action == "search":
            query = request.form.get("query", "")
            if query:
                search_criteria["$or"] = [
                    {field: {"$regex": query, "$options": "i"}} 
                    for field in customerss.find_one().keys() if field != "_id"
                ]
        elif action == "filter":
            id_from = request.form.get("id_from", "")
            id_to = request.form.get("id_to", "")
            age_from = request.form.get("age_from", "")
            age_to = request.form.get("age_to", "")
            
            if id_from or id_to:
                search_criteria["customer_id"] = {}
                if id_from:
                    search_criteria["customer_id"]["$gte"] = id_from
                if id_to:
                    search_criteria["customer_id"]["$lte"] = id_to
            
            if age_from or age_to:
                search_criteria["customer_age"] = {}
                if age_from:
                    search_criteria["customer_age"]["$gte"] = age_from
                if age_to:
                    search_criteria["customer_age"]["$lte"] = age_to
        elif action == "image_search":
            image_file = request.files.get("image_search")
            if image_file:
                image_data = image_file.read()
                results = list(customerss.find({"customer_image": Binary(image_data)}))

        if action != "image_search":
            results = list(customerss.find(search_criteria))
        
        if sort_by:
            if sort_by == "customer_id_asc":
                results.sort(key=lambda x: int(x.get("customer_id", "0")))
            elif sort_by == "customer_id_desc":
                results.sort(key=lambda x: int(x.get("customer_id", "0")), reverse=True)
            elif sort_by == "customer_name_asc":
                results.sort(key=lambda x: x.get("customer_name", "").lower())
            elif sort_by == "customer_name_desc":
                results.sort(key=lambda x: x.get("customer_name", "").lower(), reverse=True)
            elif sort_by == "customer_age_asc":
                results.sort(key=lambda x: int(x.get("customer_age", "0")))
            elif sort_by == "customer_age_desc":
                results.sort(key=lambda x: int(x.get("customer_age", "0")), reverse=True)

    elif request.args.get("show_all"):
        results = list(customerss.find())

    # Encode images to base64
    for result in results:
        if result.get("customer_image"):
            result["customer_image"] = base64.b64encode(result["customer_image"]).decode('utf-8')
    
    return render_template("search_customers.html", results=results)


# Search employees
@app.route("/employees/search", methods=["GET", "POST"])
def search_employees():
    results = []
    if request.method == "POST":
        action = request.form.get("action")
        sort_by = request.form.get("sort", "")
        
        search_criteria = {}
        
        if action == "search":
            query = request.form.get("query", "")
            if query:
                search_criteria["$or"] = [
                    {field: {"$regex": query, "$options": "i"}} 
                    for field in employees.find_one().keys() if field != "_id"
                ]
        elif action == "filter":
            id_from = request.form.get("id_from", "")
            id_to = request.form.get("id_to", "")
            
            if id_from or id_to:
                search_criteria["employee_id"] = {}
                if id_from:
                    search_criteria["employee_id"]["$gte"] = id_from
                if id_to:
                    search_criteria["employee_id"]["$lte"] = id_to
        elif action == "image_search":
            image_file = request.files.get("image_search")
            if image_file:
                image_data = image_file.read()
                results = list(employees.find({"employee_image": Binary(image_data)}))

        if action != "image_search":
            results = list(employees.find(search_criteria))
        
        if sort_by:
            if sort_by == "employee_id_asc":
                results.sort(key=lambda x: int(x.get("employee_id", "0")))
            elif sort_by == "employee_id_desc":
                results.sort(key=lambda x: int(x.get("employee_id", "0")), reverse=True)
            elif sort_by == "employee_name_asc":
                results.sort(key=lambda x: x.get("employee_name", "").lower())
            elif sort_by == "employee_name_desc":
                results.sort(key=lambda x: x.get("employee_name", "").lower(), reverse=True)

    elif request.args.get("show_all"):
        results = list(employees.find())

    # Encode images to base64
    for result in results:
        if result.get("employee_image"):
            result["employee_image"] = base64.b64encode(result["employee_image"]).decode('utf-8')
    
    return render_template("search_employees.html", results=results)


# Search equipments
@app.route("/equipments/search", methods=["GET", "POST"])
def search_equipments():
    results = []
    if request.method == "POST":
        action = request.form.get("action")
        sort_by = request.form.get("sort", "")
        
        search_criteria = {}
        
        if action == "search":
            query = request.form.get("query", "")
            if query:
                search_criteria["$or"] = [
                    {field: {"$regex": query, "$options": "i"}} 
                    for field in equipmentss.find_one().keys() if field != "_id"
                ]
        elif action == "filter":
            id_from = request.form.get("id_from", "")
            id_to = request.form.get("id_to", "")
            
            if id_from or id_to:
                search_criteria["equipment_id"] = {}
                if id_from:
                    search_criteria["equipment_id"]["$gte"] = id_from
                if id_to:
                    search_criteria["equipment_id"]["$lte"] = id_to
        elif action == "image_search":
            image_file = request.files.get("image_search")
            if image_file:
                image_data = image_file.read()
                results = list(equipmentss.find({"equipment_image": Binary(image_data)}))

        if action != "image_search":
            results = list(equipmentss.find(search_criteria))
        
        if sort_by:
            if sort_by == "equipment_id_asc":
                results.sort(key=lambda x: int(x.get("equipment_id", "0")))
            elif sort_by == "equipment_id_desc":
                results.sort(key=lambda x: int(x.get("equipment_id", "0")), reverse=True)
            elif sort_by == "equipment_name_asc":
                results.sort(key=lambda x: x.get("equipment_name", "").lower())
            elif sort_by == "equipment_name_desc":
                results.sort(key=lambda x: x.get("equipment_name", "").lower(), reverse=True)

    elif request.args.get("show_all"):
        results = list(equipmentss.find())

    # Encode images to base64
    for result in results:
        if result.get("equipment_image"):
            result["equipment_image"] = base64.b64encode(result["equipment_image"]).decode('utf-8')
        if result.get("equipment_barcode"):
            result["equipment_barcode"] = base64.b64encode(result["equipment_barcode"]).decode('utf-8')
    
    return render_template("search_equipments.html", results=results)


#############################################################################

@app.route("/customer_login", methods=['GET', 'POST'])
def customer_login():
    if request.method == 'POST':
        customer_id = request.form['customer-id']
        customer_password = request.form['customer-password']
        customer = customerss.find_one({"customer_id": customer_id})
        if customer and customer['customer_password'] == customer_password:
            session['customer_id'] = customer_id
            return redirect(url_for('customer_details'))
        else:
            flash('Invalid customer ID or password')
    return render_template('customer_login.html')

@app.route("/customer_details")
def customer_details():
    if 'customer_id' not in session:
        return redirect(url_for('customer_login'))
    customer_id = session['customer_id']
    customer = customerss.find_one({"customer_id": customer_id})
    if not customer:
        flash('Customer not found')
        return redirect(url_for('customer_login'))
    
    customer_image = base64.b64encode(customer["customer_image"]).decode('utf-8') if customer.get("customer_image") else ""
    return render_template('customer_details.html', customer=customer, customer_image=customer_image)

@app.route("/delete_user", methods=['GET', 'POST'])
def delete_user():
    if 'username' not in session:
        return redirect(url_for('index'))  # Changed from login to index
    
    if request.method == 'POST':
        username = request.form['username']
        user = users.find_one({"username": username})
        if user:
            users.delete_one({"username": username})
            flash('User deleted successfully')
            if username == session['username']:
                session.pop('username', None)
                return redirect(url_for('index'))  # Changed from login to index
        else:
            flash('User not found')
    
    all_users = list(users.find({}, {"_id": 0, "username": 1}))
    return render_template('delete_user.html', users=all_users)

db = client.flask_database # creating your flask database using your mongo client 
todos = db.todos # creating a collection called "todos"

db = client.Customer_database # creating your flask database using your mongo client 
users = db.users
customerss = db.customers # creating a collection called "customers"
equipmentss=db.equipments
employees = db.employees

# The dunder if __name__ code block
if __name__ == "__main__":
    app.run(debug=True) #running your server on development mode, setting debug to True
